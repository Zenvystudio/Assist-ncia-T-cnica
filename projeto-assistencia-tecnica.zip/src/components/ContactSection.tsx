import React, { useState } from 'react';
import { ArrowUpRight, CheckCircle2, AlertCircle, Wrench, ShieldCheck, Clock } from 'lucide-react';

interface ContactSectionProps {
  initialService?: string;
  initialModel?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ initialService, initialModel }) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [device, setDevice] = useState(initialModel || '');
  const [issue, setIssue] = useState(initialService || '');
  const [formError, setFormError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Sync if initialService or initialModel changes
  React.useEffect(() => {
    if (initialService) {
      setIssue(initialService);
    }
    if (initialModel) {
      setDevice(initialModel);
    }
  }, [initialService, initialModel]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setFormError('Por favor, informe seu nome.');
      return;
    }
    if (!contact.trim() || contact.trim().length < 8) {
      setFormError('Por favor, informe seu telefone ou WhatsApp para retorno.');
      return;
    }
    if (!issue.trim()) {
      setFormError('Por favor, descreva brevemente o defeito ou serviço.');
      return;
    }

    setFormError('');
    setSubmitted(true);
  };

  const handleReset = () => {
    setName('');
    setContact('');
    setDevice('');
    setIssue('');
    setSubmitted(false);
  };

  return (
    <section id="contato" className="py-24 sm:py-32 border-b border-neutral-900 bg-black relative">
      <div className="max-w-4xl mx-auto px-5 sm:px-8">
        
        {/* Section Header: Centered & Authoritative */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Atendimento & Diagnóstico
          </div>
          <h2 className="section-title-clamp font-bold text-white tracking-tight text-balance">
            Solicite a análise técnica do seu equipamento.
          </h2>
          <p className="mt-4 text-base text-neutral-300">
            Envie as informações do seu aparelho. Nossa bancada técnica especializada analisará o caso e retornará diretamente pelo contato informado.
          </p>
        </div>

        {/* Lead Capture Form Card */}
        <div className="rounded-2xl border border-neutral-900 bg-[#0c0c0c] p-8 sm:p-12 shadow-2xl backdrop-blur-md relative overflow-hidden">
          
          {/* Subtle Golden Ambient Accent */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#D4AF37]/5 blur-3xl pointer-events-none rounded-full" />

          {formError && (
            <div className="mb-8 p-4 rounded-xl bg-red-950/40 border border-red-900/60 text-red-300 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{formError}</span>
            </div>
          )}

          {submitted ? (
            <div className="py-12 text-center space-y-6">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white">
                  Solicitação Registrada com Sucesso
                </h3>
                <p className="text-base text-neutral-300 max-w-md mx-auto leading-relaxed">
                  Recebemos os detalhes do seu equipamento. Nossa equipe técnica entrará em contato pelo telefone <strong className="text-white font-mono-numbers">{contact}</strong> para orientar os próximos passos do diagnóstico.
                </p>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-neutral-800 hover:border-neutral-700 bg-neutral-950 text-neutral-300 hover:text-white text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  Enviar Outra Solicitação
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="contactName" className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-2">
                    Seu Nome *
                  </label>
                  <input
                    id="contactName"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Carlos Silva"
                    required
                    className="w-full px-4 py-3.5 rounded-xl bg-black border border-neutral-800 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                </div>

                <div>
                  <label htmlFor="contactPhone" className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-2">
                    Telefone / WhatsApp para Retorno *
                  </label>
                  <input
                    id="contactPhone"
                    type="tel"
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="DDD + Seu número"
                    required
                    className="w-full px-4 py-3.5 rounded-xl bg-black border border-neutral-800 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="contactDevice" className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-2">
                  Marca e Modelo do Equipamento
                </label>
                <input
                  id="contactDevice"
                  type="text"
                  value={device}
                  onChange={(e) => setDevice(e.target.value)}
                  placeholder="Ex: iPhone 13 Pro, MacBook Pro M1, Dell Inspiron, PC Gamer..."
                  className="w-full px-4 py-3.5 rounded-xl bg-black border border-neutral-800 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                />
              </div>

              <div>
                <label htmlFor="contactIssue" className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-2">
                  Descreva o Defeito ou Reparo Necessário *
                </label>
                <textarea
                  id="contactIssue"
                  rows={4}
                  value={issue}
                  onChange={(e) => setIssue(e.target.value)}
                  placeholder="Ex: Tela trincada, não segura carga, molhou na chuva, computador desliga sozinho..."
                  required
                  className="w-full px-4 py-3.5 rounded-xl bg-black border border-neutral-800 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37] transition-colors resize-none"
                />
              </div>

              {/* Guarantees Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 pb-2 text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Garantia de 90 a 180 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Peças Padrão Original</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Diagnóstico sem compromisso</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-3 py-4 px-8 text-sm font-semibold uppercase tracking-wider text-black bg-[#D4AF37] rounded-xl hover:bg-[#e0bc45] active:scale-[0.98] transition-all duration-150 shadow-md shadow-[#D4AF37]/15"
              >
                <span>Enviar Solicitação de Diagnóstico</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </form>
          )}

        </div>

      </div>
    </section>
  );
};
