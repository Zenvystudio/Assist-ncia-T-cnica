import React from 'react';
import labImage from '@/src/assets/images/lab_diagnostic_station_1792171185570.jpg';
import macroImage from '@/src/assets/images/repair_precision_macro_1792171185378.jpg';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 sm:py-32 border-b border-neutral-900 bg-black relative">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Editorial 2-Column Split: Image on Left, Content on Right (Inverting rhythm) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Composite High-End Photography */}
          <div className="lg:col-span-6 relative">
            <div className="rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-950">
              <img
                src={labImage}
                alt="Laboratório técnico de computadores, MacBooks e smartphones"
                className="w-full h-[380px] sm:h-[460px] object-cover object-center"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Overlapping Precision Macro Inset */}
            <div className="hidden sm:block absolute -bottom-8 -right-6 w-48 sm:w-56 h-36 sm:h-44 rounded-xl overflow-hidden border-2 border-[#D4AF37]/50 shadow-2xl bg-black">
              <img
                src={macroImage}
                alt="Microsoldagem de alta precisão em placa eletrônica"
                className="w-full h-full object-cover"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Right Column: Editorial Text & Concrete Operational Standards */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
              Sobre Nossa Assistência Técnica
            </div>
            
            <h2 className="section-title-clamp font-bold text-white tracking-tight mb-6 text-balance">
              Rigores de laboratório aplicados à manutenção diária.
            </h2>

            <p className="text-base text-neutral-300 leading-relaxed mb-6">
              Nossa assistência técnica foi estruturada para erradicar diagnósticos superficiais e substituições desnecessárias de módulos completos.
            </p>

            <p className="text-base text-neutral-300 leading-relaxed mb-10">
              Investimos em instrumentação avançada de bancada — incluindo microscopia estereoscópica, osciloscópios digitais e estações térmicas de microprecisão — permitindo a recuperação de componentes que assistências comuns consideram irrecuperáveis.
            </p>

            {/* Concrete Statistics & Guarantees - Tabular Numerals */}
            <div className="grid grid-cols-2 gap-6 pt-6 border-t border-neutral-900">
              <div>
                <div className="font-mono-numbers text-3xl font-bold text-[#D4AF37]">
                  100%
                </div>
                <div className="text-xs text-neutral-400 mt-1 uppercase tracking-wider font-medium">
                  Com Ordem de Serviço
                </div>
                <p className="text-xs text-neutral-400 mt-1">
                  Transparência absoluta e registro de cada procedimento realizado.
                </p>
              </div>

              <div>
                <div className="font-mono-numbers text-3xl font-bold text-[#D4AF37]">
                  90 a 180
                </div>
                <div className="text-xs text-neutral-400 mt-1 uppercase tracking-wider font-medium">
                  Dias de Garantia
                </div>
                <p className="text-xs text-neutral-400 mt-1">
                  Proteção contratual assegurada para peças e serviços executados.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
