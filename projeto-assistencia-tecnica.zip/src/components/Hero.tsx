import React from 'react';
import { ArrowUpRight, ShieldCheck, ChevronDown } from 'lucide-react';
import heroImage from '@/src/assets/images/hero_workbench_electronics_1792171184846.jpg';

interface HeroProps {
  onContactClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onContactClick }) => {
  return (
    <section id="inicio" className="relative pt-28 pb-16 sm:pt-36 sm:pb-24 overflow-hidden border-b border-neutral-900 bg-black">
      {/* Background ambient lighting - restrained, not messy */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[350px] bg-[#D4AF37]/5 blur-[140px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Editorial Trust Kicker: Unboxed, clean text with typographic separator */}
        <div className="flex items-center gap-2 text-xs sm:text-sm font-medium tracking-wide text-neutral-400 mb-6">
          <span className="text-[#D4AF37] font-semibold">Laboratório Especializado</span>
          <span aria-hidden="true" className="text-neutral-700">·</span>
          <span>Microsoldagem & Reparo Avançado de Hardware</span>
        </div>

        {/* Hero Grid Split with balanced typography and cinematic image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headline, One-Line Support, CTA */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <h1 className="hero-title-clamp font-bold text-white tracking-tight mb-6 text-balance">
              Restauração de precisão para seus <span className="text-[#D4AF37]">eletrônicos vitais</span>.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 max-w-xl leading-relaxed mb-8">
              Assistência técnica de alto padrão para smartphones, computadores e MacBooks com diagnóstico direto em bancada.
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onContactClick}
                className="group inline-flex items-center justify-center gap-3 px-8 py-4 text-sm font-semibold uppercase tracking-wider text-black bg-[#D4AF37] rounded-xl hover:bg-[#e0bc45] active:scale-[0.98] transition-all duration-150 shadow-lg shadow-[#D4AF37]/15"
              >
                <span>Entrar em contato</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>

              <a
                href="#cardapio"
                className="inline-flex items-center justify-center px-6 py-4 text-sm font-medium text-neutral-300 hover:text-white border border-neutral-800 rounded-xl hover:border-neutral-600 bg-neutral-950/80 transition-all duration-150"
              >
                Consultar Cardápio Express
              </a>
            </div>

            {/* Quiet Trust Footnote */}
            <div className="mt-8 pt-6 border-t border-neutral-900 flex items-center gap-3 text-xs text-neutral-400">
              <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <span>Garantia formal com emissão de Ordem de Serviço em todos os reparos.</span>
            </div>
          </div>

          {/* Right Column: Dominant Hero Showcase Image */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-950">
              {/* Subtle top-right golden accent hairline */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60 z-10 pointer-events-none" />
              <img
                src={heroImage}
                alt="Bancada de alta precisão com microscópio Leica e técnicos especializados em manutenção eletrônica"
                className="w-full h-[360px] sm:h-[440px] lg:h-[480px] object-cover object-center transform hover:scale-[1.02] transition-transform duration-700 ease-out"
                loading="eager"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

        {/* Peek invitation to scroll */}
        <div className="pt-10 flex justify-center">
          <a
            href="#servicos"
            className="inline-flex flex-col items-center gap-2 text-xs uppercase tracking-widest text-slate-400 hover:text-[#D4AF37] transition-colors"
            aria-label="Rolar para seção de serviços"
          >
            <span>Conhecer Especialidades</span>
            <ChevronDown className="w-4 h-4 animate-bounce" />
          </a>
        </div>
      </div>
    </section>
  );
};
