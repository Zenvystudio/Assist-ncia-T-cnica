import React, { useState } from 'react';
import { DIGITAL_MENU_CATEGORIES } from '@/src/data/services';
import { Smartphone, Laptop, Monitor, Clock, CheckCircle2, ArrowRight } from 'lucide-react';

interface DigitalMenuSectionProps {
  onSelectIssue?: (issue: string, model: string) => void;
}

export const DigitalMenuSection: React.FC<DigitalMenuSectionProps> = ({ onSelectIssue }) => {
  const [activeTab, setActiveTab] = useState<'smartphones' | 'notebooks' | 'desktops'>('smartphones');
  const [selectedIssue, setSelectedIssue] = useState<string>('Vidro quebrado ou tela preta');
  const [deviceModel, setDeviceModel] = useState<string>('');

  const currentCategory = DIGITAL_MENU_CATEGORIES[activeTab];

  const handleInquiry = () => {
    if (onSelectIssue) {
      onSelectIssue(selectedIssue, deviceModel);
    } else {
      const contactElem = document.getElementById('contato');
      if (contactElem) {
        contactElem.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const getIcon = (key: string) => {
    switch (key) {
      case 'smartphones':
        return <Smartphone className="w-4 h-4" />;
      case 'notebooks':
        return <Laptop className="w-4 h-4" />;
      case 'desktops':
        return <Monitor className="w-4 h-4" />;
      default:
        return <Smartphone className="w-4 h-4" />;
    }
  };

  return (
    <section id="cardapio" className="py-24 sm:py-32 border-b border-neutral-900 bg-black">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Heading */}
        <div className="max-w-2xl mb-12">
          <div className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Cardápio Digital de Serviços
          </div>
          <h2 className="section-title-clamp font-bold text-white tracking-tight text-balance">
            Consulte sintomas e prazos de bancada.
          </h2>
          <p className="mt-4 text-base text-neutral-300">
            Selecione a categoria do seu equipamento para simular a estimativa de reparo e enviar os detalhes para nossa bancada.
          </p>
        </div>

        {/* Device Category Tabs */}
        <div className="flex flex-wrap items-center gap-3 p-1.5 bg-[#0d0d0d] rounded-2xl border border-neutral-900 w-fit mb-10">
          {(['smartphones', 'notebooks', 'desktops'] as const).map((tabKey) => {
            const isActive = activeTab === tabKey;
            return (
              <button
                key={tabKey}
                onClick={() => {
                  setActiveTab(tabKey);
                  const firstIssue = DIGITAL_MENU_CATEGORIES[tabKey].commonIssues[0].title;
                  setSelectedIssue(firstIssue);
                }}
                className={`inline-flex items-center gap-2.5 px-5 py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all duration-150 whitespace-nowrap ${
                  isActive
                    ? 'bg-[#D4AF37] text-black shadow-md shadow-[#D4AF37]/15'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                {getIcon(tabKey)}
                <span>{DIGITAL_MENU_CATEGORIES[tabKey].name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Interactive Menu Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Issue Cards Selection List */}
          <div className="lg:col-span-7 space-y-4">
            {currentCategory.commonIssues.map((issue) => {
              const isSelected = selectedIssue === issue.title;
              return (
                <div
                  key={issue.title}
                  onClick={() => setSelectedIssue(issue.title)}
                  className={`cursor-pointer rounded-2xl p-6 border transition-all duration-150 relative ${
                    isSelected
                      ? 'border-[#D4AF37] bg-[#121212] shadow-lg shadow-[#D4AF37]/5'
                      : 'border-neutral-900 bg-[#0a0a0a] hover:border-neutral-800 hover:bg-[#0f0f0f]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3.5">
                      <div className={`mt-0.5 rounded-full p-1 transition-colors ${isSelected ? 'text-[#D4AF37]' : 'text-neutral-600'}`}>
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-base font-semibold text-white mb-1">
                          {issue.title}
                        </h4>
                        <p className="text-sm text-neutral-300">
                          {issue.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-mono-numbers text-neutral-400 shrink-0 pt-0.5">
                      <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>{issue.estimatedTime}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Lead Summary & Instant Dispatch Box */}
          <div className="lg:col-span-5 sticky top-28 rounded-2xl border border-[#D4AF37]/30 bg-[#0c0c0c] p-7 sm:p-8 backdrop-blur-xl">
            <div className="flex items-center justify-between pb-5 border-b border-neutral-900 mb-6">
              <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Orçamento Expresso</span>
              <span className="text-xs font-mono-numbers text-[#D4AF37]">Diagnóstico Sem Custo</span>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-2">
                  Defeito Selecionado
                </label>
                <div className="p-3.5 rounded-xl bg-black border border-neutral-800 text-sm font-semibold text-white">
                  {selectedIssue}
                </div>
              </div>

              <div>
                <label htmlFor="modelInput" className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-2">
                  Qual é o modelo exato? (opcional)
                </label>
                <input
                  id="modelInput"
                  type="text"
                  value={deviceModel}
                  onChange={(e) => setDeviceModel(e.target.value)}
                  placeholder="Ex: iPhone 14 Pro, Dell Inspiron 15, MacBook Air M1..."
                  className="w-full px-4 py-3 rounded-xl bg-black border border-neutral-800 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                />
              </div>
            </div>

            <div className="space-y-3 mb-6 text-xs text-neutral-400">
              <div className="flex items-center justify-between">
                <span>Ordem de Serviço Oficial:</span>
                <span className="text-neutral-200 font-medium">Inclusa</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Garantia de Bancada:</span>
                <span className="text-neutral-200 font-medium">90 a 180 dias</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Procedimento:</span>
                <span className="text-neutral-200 font-medium">Inspeção direta de hardware</span>
              </div>
            </div>

            <button
              onClick={handleInquiry}
              className="w-full inline-flex items-center justify-center gap-3 py-4 px-6 text-sm font-semibold uppercase tracking-wider text-black bg-[#D4AF37] rounded-xl hover:bg-[#e0bc45] active:scale-[0.98] transition-all duration-150 shadow-md shadow-[#D4AF37]/15"
            >
              <span>Continuar Solicitação</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-[11px] text-center text-neutral-400 mt-3">
              Resposta ágil direto da nossa bancada técnica especializada.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
