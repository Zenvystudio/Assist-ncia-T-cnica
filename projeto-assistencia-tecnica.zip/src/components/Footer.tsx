import React from 'react';
import { ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-black border-t border-neutral-900 py-16 text-neutral-400">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-neutral-900">
          <div>
            <a href="#inicio" className="text-xl font-bold tracking-tight text-white hover:text-[#D4AF37] transition-colors uppercase">
              Assistência <span className="text-[#D4AF37]">Técnica</span>
            </a>
            <p className="text-xs text-neutral-400 mt-2 max-w-sm">
              Laboratório especializado em manutenção e microsoldagem para smartphones, computadores e MacBooks.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 sm:gap-8 text-xs font-medium text-neutral-300">
            <a href="#inicio" className="hover:text-[#D4AF37] transition-colors">Início</a>
            <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Serviços</a>
            <a href="#cardapio" className="hover:text-[#D4AF37] transition-colors">Cardápio Express</a>
            <a href="#sobre" className="hover:text-[#D4AF37] transition-colors">Sobre</a>
            <a href="#contato" className="hover:text-[#D4AF37] transition-colors">Contato</a>
          </div>

          <button
            onClick={scrollToTop}
            className="p-3 rounded-xl border border-neutral-800 hover:border-[#D4AF37]/50 text-neutral-400 hover:text-white bg-neutral-950 transition-colors"
            aria-label="Voltar ao topo da página"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            Laboratório Técnico Especializado em Hardware & Microsoldagem
          </div>
          <div>
            © {new Date().getFullYear()} Assistência Técnica. Todos os direitos reservados.
          </div>
        </div>

      </div>
    </footer>
  );
};
