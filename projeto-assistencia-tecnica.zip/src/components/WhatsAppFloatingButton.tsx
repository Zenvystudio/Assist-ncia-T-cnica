import React from 'react';
import { Wrench } from 'lucide-react';

export const WhatsAppFloatingButton: React.FC = () => {
  const scrollToContact = () => {
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <aside aria-label="Solicitar diagnóstico rápido" className="fixed bottom-6 right-6 z-40">
      <button
        onClick={scrollToContact}
        aria-label="Solicitar Diagnóstico Técnico"
        className="group relative flex items-center gap-2.5 px-4 py-3 bg-[#D4AF37] text-black font-semibold text-xs uppercase tracking-wider rounded-full shadow-2xl hover:bg-[#e0bc45] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
      >
        <Wrench className="w-4 h-4" />
        <span className="hidden sm:inline">Solicitar Diagnóstico</span>
      </button>
    </aside>
  );
};
