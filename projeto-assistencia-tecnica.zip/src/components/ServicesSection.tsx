import React from 'react';
import { SERVICES_DATA, ServiceItem } from '@/src/data/services';
import { ArrowUpRight, Shield } from 'lucide-react';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  return (
    <section id="servicos" className="py-24 sm:py-32 border-b border-neutral-900 bg-black relative">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        
        {/* Section Header: Minimalist, authoritative, zero boilerplate */}
        <div className="max-w-2xl mb-16 sm:mb-20">
          <div className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Especialidades de Bancada
          </div>
          <h2 className="section-title-clamp font-bold text-white tracking-tight text-balance">
            Soluções definitivas para falhas críticas.
          </h2>
          <p className="mt-4 text-base text-neutral-300">
            Cada protocolo segue tolerâncias estritas de fábrica e testes funcionais abrangentes antes da entrega.
          </p>
        </div>

        {/* Asymmetric Bento Architecture: 8 Services with distinctive rhythm on deep black */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {SERVICES_DATA.map((service, idx) => {
            const colSpanClass =
              idx === 0
                ? 'lg:col-span-7 bg-gradient-to-br from-[#121212] to-[#080808] border-neutral-800'
                : idx === 1
                ? 'lg:col-span-5 bg-gradient-to-br from-[#121212] to-[#050505] border-neutral-800'
                : 'lg:col-span-4 bg-[#0a0a0a] border-neutral-900';

            const isMarquee = idx === 0 || idx === 1;

            return (
              <div
                key={service.id}
                className={`relative rounded-2xl p-7 sm:p-8 border hover:border-[#D4AF37]/50 transition-all duration-200 flex flex-col justify-between group ${colSpanClass}`}
              >
                <div>
                  {/* Card Editorial Header: Number & Category */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-mono-numbers text-xl font-bold text-[#D4AF37]">
                      {service.number}
                    </span>
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                      {service.turnaround}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className={`font-bold text-white mb-3 group-hover:text-[#D4AF37] transition-colors ${isMarquee ? 'text-2xl' : 'text-xl'}`}>
                    {service.title}
                  </h3>
                  <p className="text-sm text-neutral-300 leading-relaxed mb-6">
                    {service.shortDesc}
                  </p>

                  {/* Bullet points without decorative clutter */}
                  <ul className="space-y-2 mb-8">
                    {service.features.map((feat, fIdx) => (
                      <li key={fIdx} className="text-xs text-neutral-400 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]/80 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Bottom Row: Warranty + Action trigger */}
                <div className="pt-6 border-t border-neutral-900 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                    <Shield className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{service.warranty}</span>
                  </div>

                  <button
                    onClick={() => onSelectService(service)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#D4AF37] hover:text-white transition-colors py-1"
                  >
                    <span>Solicitar</span>
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
