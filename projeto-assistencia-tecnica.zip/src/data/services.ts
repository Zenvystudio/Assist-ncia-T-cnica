export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  category: 'smartphones' | 'computadores' | 'especializados';
  shortDesc: string;
  turnaround: string;
  warranty: string;
  features: string[];
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'telas',
    number: '01',
    title: 'Troca de Telas Originais & OLED',
    category: 'smartphones',
    shortDesc: 'Substituição de displays com preservação de True Tone, calibração tátil e vedação.',
    turnaround: 'Express · 40 a 60 min',
    warranty: 'Garantia de 90 dias',
    features: ['Calibração de touch e brilho', 'Vedação técnica de fábrica', 'Testes de cores e resposta rápida']
  },
  {
    id: 'microsoldagem',
    number: '02',
    title: 'Reparo de Placa & Microsoldagem',
    category: 'especializados',
    shortDesc: 'Diagnóstico por osciloscópio, reballing, reparo de linhas em curto e troca de CIs.',
    turnaround: '24 a 48 horas',
    warranty: 'Garantia de 120 dias',
    features: ['Recuperação de aparelhos sem sinal', 'Correção de falhas de carga/áudio', 'Microscopia de alta precisão']
  },
  {
    id: 'baterias',
    number: '03',
    title: 'Baterias Homologadas Saúde 100%',
    category: 'smartphones',
    shortDesc: 'Baterias novas de alta densidade sem avisos de incompatibilidade no sistema.',
    turnaround: 'Express · 30 a 50 min',
    warranty: 'Garantia de 90 dias',
    features: ['Ciclo zero de carga', 'Autonomia máxima restabelecida', 'Sem superaquecimento']
  },
  {
    id: 'molhados',
    number: '04',
    title: 'Recuperação de Aparelhos Molhados',
    category: 'especializados',
    shortDesc: 'Banho químico ultrassônico para neutralização imediata de oxidação galvânica.',
    turnaround: '24 a 72 horas',
    warranty: 'Conforme laudo técnico',
    features: ['Desoxidação de circuitos integrados', 'Secagem em estufa controlada', 'Recuperação de dados vitais']
  },
  {
    id: 'macbooks',
    number: '05',
    title: 'Reparo em MacBooks & Laptops',
    category: 'computadores',
    shortDesc: 'Manutenção em circuito lógico, teclado, trackpad, tela Retina e fonte de alimentação.',
    turnaround: '24 a 48 horas',
    warranty: 'Garantia de 120 dias',
    features: ['Especialistas em linhas Intel e Apple Silicon', 'Troca de displays e conectores', 'Reparo de chipsets']
  },
  {
    id: 'termica',
    number: '06',
    title: 'Manutenção Térmica de Alto Rendimento',
    category: 'computadores',
    shortDesc: 'Higienização de coolers, dissipadores e aplicação de composto térmico de alta condutividade.',
    turnaround: 'Mesmo dia · 2 a 4 horas',
    warranty: 'Garantia de 90 dias',
    features: ['Redução drástica de temperatura', 'Eliminação de throttling térmico', 'Operação silenciosa e estável']
  },
  {
    id: 'upgrades',
    number: '07',
    title: 'Upgrade de SSD & Memória RAM',
    category: 'computadores',
    shortDesc: 'Multiplicação de velocidade com NVMe de alta taxa de leitura e expansão de memória.',
    turnaround: 'Mesmo dia · 2 a 3 horas',
    warranty: 'Garantia de 180 dias',
    features: ['Clonagem integral do sistema original', 'Zero perda de arquivos e programas', 'Boot em menos de 10 segundos']
  },
  {
    id: 'conectores',
    number: '08',
    title: 'Conectores Tipo-C, Lightning & Áudio',
    category: 'smartphones',
    shortDesc: 'Substituição de subplacas de carga, microfones com ruído e conectores frouxos.',
    turnaround: 'Express · 40 min',
    warranty: 'Garantia de 90 dias',
    features: ['Suporte total a carregamento rápido', 'Transmissão de dados sem oscilação', 'Áudio límpido e sem chiados']
  }
];

export interface MenuDeviceCategory {
  name: string;
  icon: string;
  commonIssues: {
    title: string;
    description: string;
    estimatedTime: string;
  }[];
}

export const DIGITAL_MENU_CATEGORIES: Record<string, MenuDeviceCategory> = {
  smartphones: {
    name: 'Smartphones (iPhone & Android)',
    icon: 'Smartphone',
    commonIssues: [
      {
        title: 'Vidro quebrado ou tela preta',
        description: 'Troca de display mantendo taxa de resposta e biometria.',
        estimatedTime: '40 a 60 min'
      },
      {
        title: 'Bateria descarregando rápido',
        description: 'Instalação de célula nova certificada com 100% de saúde.',
        estimatedTime: '30 a 50 min'
      },
      {
        title: 'Cabo não encaixa ou não carrega',
        description: 'Limpeza técnica ou substituição do conector de carga.',
        estimatedTime: '30 a 60 min'
      },
      {
        title: 'Aparelho travou no logotipo / não liga',
        description: 'Diagnóstico lógico de placa mãe e memória UFS/NAND.',
        estimatedTime: '24 a 48 horas'
      }
    ]
  },
  notebooks: {
    name: 'Notebooks & MacBooks',
    icon: 'Laptop',
    commonIssues: [
      {
        title: 'Lentidão severa ao abrir programas',
        description: 'Instalação de SSD ultrarrápido com clonagem de dados.',
        estimatedTime: '2 a 3 horas'
      },
      {
        title: 'Esquentando muito e barulho no cooler',
        description: 'Manutenção preventiva com troca de pasta térmica.',
        estimatedTime: '2 a 4 horas'
      },
      {
        title: 'Teclas falhando ou líquido derramado',
        description: 'Substituição do teclado e desoxidação de componentes.',
        estimatedTime: '24 a 48 horas'
      },
      {
        title: 'Sem imagem na tela ou dobradiça solta',
        description: 'Reparo de cabo flat / display ou reconstrução de carcaça.',
        estimatedTime: '24 horas'
      }
    ]
  },
  desktops: {
    name: 'Computadores Gamer & Workstations',
    icon: 'Monitor',
    commonIssues: [
      {
        title: 'PC liga mas não dá vídeo (bips)',
        description: 'Diagnóstico em bancada de GPU, slots de RAM e placa-mãe.',
        estimatedTime: 'Mesmo dia'
      },
      {
        title: 'Otimização para jogos e renderização',
        description: 'Upgrade balanceado de fonte, memória e refrigeração.',
        estimatedTime: 'Mesmo dia'
      },
      {
        title: 'Fonte queimada após oscilação de luz',
        description: 'Substituição por fonte com PFC Ativo e certificação 80 Plus.',
        estimatedTime: '1 a 2 horas'
      }
    ]
  }
};
