import React, { useState } from 'react';
import { Header } from '@/src/components/Header';
import { Hero } from '@/src/components/Hero';
import { ServicesSection } from '@/src/components/ServicesSection';
import { DigitalMenuSection } from '@/src/components/DigitalMenuSection';
import { AboutSection } from '@/src/components/AboutSection';
import { ContactSection } from '@/src/components/ContactSection';
import { Footer } from '@/src/components/Footer';
import { WhatsAppFloatingButton } from '@/src/components/WhatsAppFloatingButton';
import { ServiceItem } from '@/src/data/services';

export default function App() {
  const [selectedServiceForContact, setSelectedServiceForContact] = useState<string>('');
  const [selectedModelForContact, setSelectedModelForContact] = useState<string>('');

  const handleSelectService = (service: ServiceItem) => {
    setSelectedServiceForContact(service.title);
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectIssueFromMenu = (issue: string, model: string) => {
    setSelectedServiceForContact(issue);
    setSelectedModelForContact(model);
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleContactClick = () => {
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col selection:bg-[#D4AF37] selection:text-black">
      {/* Fixed Navigation adhering to 3-zone contract */}
      <Header onContactClick={handleContactClick} />

      {/* Main Content Flow */}
      <main className="flex-1">
        {/* 01. Hero with clamp typography, pristine image & primary CTA */}
        <Hero onContactClick={handleContactClick} />

        {/* 02. Core Capabilities: 8 Distinctive Services with Bento Rhythm */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* 03. Cardápio Digital: Interactive Device & Symptom Selector */}
        <DigitalMenuSection onSelectIssue={handleSelectIssueFromMenu} />

        {/* 04. Proof & Laboratory: About Section with Macro Photography & Standards */}
        <AboutSection />

        {/* 05. Conversion: Clean Lead Capture Form */}
        <ContactSection
          initialService={selectedServiceForContact}
          initialModel={selectedModelForContact}
        />
      </main>

      {/* 06. Restrained Minimalist Footer */}
      <Footer />

      {/* Ambient Quick Access */}
      <WhatsAppFloatingButton />
    </div>
  );
}
